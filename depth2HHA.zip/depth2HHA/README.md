# rgbd-image-processor

This is a project tackling rgbd image. 
Thanks for the theory from [Learning Rich Features from RGB-D Images for Object Detection and Segmentation](https://people.eecs.berkeley.edu/~sgupta/pdf/rcnn-depth.pdf) and implementation by [gupta](https://github.com/s-gupta/rcnn-depth).

With reference to this paper, I extracted the part to get HHA image and then extend this project to build a heightMap(i.e height above ground in real scene). Thanks
