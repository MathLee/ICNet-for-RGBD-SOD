clc;
clear;
C = cropCamera(getCameraParam('color'));
%C = getCameraParam('color');
dataset_name = '/home/lgy/flownet2-master/RGBD_MODEL/RGBDdata/cvpr2019_dataset/SSD/';
path_depth = [dataset_name 'depth/'];
path_raw = path_depth;
file = dir([path_depth '*.png']);
num = length(file);
pathsave = [dataset_name 'HHA/'];
for id  = 1:num
    id
    name = file(id).name;
    named = [path_depth,name];
D = imread(named);

D = double(D)./80;
[height,width] = size(D);
namerd = [path_raw,name];
RD = imread(namerd);
missingMask = (RD == 0);
[pc, N, yDir, h, pcRot, NRot] = processDepthImage(D*100, missingMask, C);
angl = acosd(min(1,max(-1,sum(bsxfun(@times, N, reshape(yDir, 1, 1, 3)), 3))));
    
% Making the minimum depth to be 100, to prevent large values for disparity!!!
pc(:,:,3) = max(pc(:,:,3), 100);
a = pc(:,:,3);
I(:,:,1) = 31000./pc(:,:,3); 
I(:,:,2) = h;
I(:,:,3) = (angl+128-90); %Keeping some slack
HHA = uint8(I);
namesave = [pathsave,name(1:end-4),'.jpg'];
%imwrite(HHA(:,:,2), 'imgs/height2.png')
imwrite(HHA, namesave);
clear I;
end
%%%
% figure()
% subplot(221)
% imshow(HHA(:,:,1))
% title('Disparity')
% subplot(222)
% imshow(HHA(:,:,2))
% title('Height')
% subplot(223)
% imshow(HHA(:,:,3))
% title('Angle')


